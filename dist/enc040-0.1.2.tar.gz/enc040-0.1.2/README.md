```bash
pip install enc040
```

### Example in example.py